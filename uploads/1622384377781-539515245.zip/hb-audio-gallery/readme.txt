=== HB AUDIO GALLERY ===
Contributors: Team HB WEBSOL
Tags: album, audio, mp3, music, playlist, audio player, sound, music player, player 
Requires at least: 4.0
Tested up to: 5.7.1
Requires PHP: 7.0
Stable tag: 2.0
License: GPLv2 or later

An easy to use, modern looking audio player plugin. Works on all modern browsers including iPhone/iPad.

== Description ==

<strong>Demo Link :</strong><br> <a href="https://wpaudiogallery.husainbandookwala.com/" target="_blank">https://wpaudiogallery.husainbandookwala.com</a>

Free support, just skype us on "hbwebsol"

HB Audio Gallery is a HTML5 based, simple and responsive audio player plugin which supports custom post type, shortcodes and works on all Browsers & devices. It Doesn't matter how big your mp3 file is, it will work on this plugin.

https://youtu.be/grxeLlLPEGk

<div>Some of its features are :-
<ul><li>HTML5 based Audio Player.</li>
<li>Responsive Audio Player, compatible to iPhone, Tablets, Laptops etc.</li>
<li>Custom Post Type Support.</li>
<li>Upload Audio Files from WordPress admin section.</li>
<li>Upload Large Audio Files directly via FTP using (Filezilla etc.).</li>
<li>Short codes available for inserting Single Audio Player, Audio Gallery Player (With Play list), Gallery lists.</li>
<li>Support multiple short codes on single post or page.</li>
<li>Compatible with other JavaScript libraries.</li>
<li>You can control audio files order in playlist.</li>
<li>You can insert artist photo.</li>
<li>Enable/Disable download Audio files (Setting Available).</li>
<li>Enable/Disable Share Audio on Facebook (Setting Available).</li>
<li>Enable/Disable Share Audio on Other Social Services (Setting Available).</li></ul></div>

== Installation ==

Upload the plugin folder to the '/wp-content/plugins/' directory

Activate the plugin through the 'Plugins' menu in WordPress Admin Area.

== Upgrade Notice ==
Here is the updated Doc or FAQ link:- <a href="https://wpaudiogallery.husainbandookwala.com" target="_blank">https://wpaudiogallery.husainbandookwala.com </a>

== Screenshots ==
1. Demo Page.
2. Settings page.
3. Main page.
4. Editing Page.

== Frequently Asked Questions ==
HB Audio Gallery Demo Link :- <a href="https://wpaudiogallery.husainbandookwala.com" target="_blank">https://wpaudiogallery.husainbandookwala.com </a> <br>

Plugin Updated Doc or FAQ Link :- <a href="https://wpaudiogallery.husainbandookwala.com" target="_blank">https://wpaudiogallery.husainbandookwala.com </a>

If you have any problems, questions or suggestions then you can <br>
Email us on <a href="mailto:info@hbwebsol.com" target="_blank">info@hbwebsol.com</a><br>
Skype us on hbwebsol<br>
 
== Support ==
If you have any problems, questions or suggestions then you can <br>
Email us on <a href="mailto:info@hbwebsol.com" target="_blank">info@hbwebsol.com</a><br>
Skype us on hbwebsol<br>

== Changelog ==
Bug fixes.