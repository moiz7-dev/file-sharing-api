jQuery.fn.exists = function () {
    return jQuery(this).length > 0;
}

const favAddedIcon = hb_object.pluginUrl + '/images/favourite-16.png';
const favRemovedIcon = hb_object.pluginUrl + '/images/not-favourite-16.jpg';
const userId = hb_object.userId;

jQuery(document).ready(function() {
    // non registered user
    if (userId == 0) {
        jQuery('#no_fav_access').load(noFavAccessTemplate);
    }
})

const favouriteSong = function(id, audio) {

    // non registered user
    if (userId == 0) {
        window.location.replace(hb_object.loginUrl);
        return;
    }

    const favIcon = jQuery('#fav-' + audio)

    favIcon.attr('src').includes('favourite-16.png') ? favIcon.attr('src', favRemovedIcon) : favIcon.attr('src', favAddedIcon)

    jQuery.ajax({
        url: hb_object.ajaxUrl,

        method: 'POST',

        data: {
            action: 'hb_favourites',
            audio_id: id
        }
    })
}